﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace система_учета_успеваемости
{
    public partial class AddGroupForm : Form
    {
        public AddGroupForm()
        {
            InitializeComponent();
            dataGridView1.Update();
        }

        private void GoBackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainAdminForm NF = new MainAdminForm();
            NF.Show();
        }

        private void AddGroupForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void AddGroupButton_Click(object sender, EventArgs e)
        {
            using (testEntities db = new testEntities())
            {
                try
                {
                    var group = db.Groups;
                    bool i = false;
                    foreach (Groups u in db.Groups)
                    {
                        if (Convert.ToInt32(textBox1.Text) == u.Group)
                        {
                            i = true;
                        }
                    }
                    if (i == true)
                    {
                        MessageBox.Show("Ошибка!");
                    }
                    else
                    {
                        Groups groups = new Groups { Group = Convert.ToInt32(textBox1.Text), Year = Convert.ToInt32(textBox2.Text) };
                        db.Groups.Add(groups);
                        db.SaveChanges();
                        MessageBox.Show("Группа успешно добавлена!");
                        dataGridView1.Update();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "Ошибка!");
                }

            }
        }

        private void AddGroupForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "testDataSet.Groups". При необходимости она может быть перемещена или удалена.
            this.groupsTableAdapter.Fill(this.testDataSet.Groups);

        }
    }
}
