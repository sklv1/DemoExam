﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace система_учета_успеваемости
{
    public partial class AutorizationForm : Form
    {
        public AutorizationForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (testEntities db = new testEntities())
            {
                try
                { 
                var user = db.Users;
                bool i = false;
                foreach (Users u in db.Users)
                {
                    if ((textBox1.Text == u.Login_Stud || textBox1.Text == u.Login_Teach || textBox1.Text == u.Login_Admin || textBox1.Text == u.Login_Directory) && textBox2.Text == u.Password)
                    {
                        i = true;
                        if (u.Role == "Студент")
                        {
                            MessageBox.Show("Успешный вход!");
                            this.Hide();
                            MainStudentForm NF = new MainStudentForm();
                            NF.Show();
                        }
                        if (u.Role == "Преподаватель")
                        {
                            MessageBox.Show("Успешный вход!");
                            this.Hide();
                            MainTeacherForm NF = new MainTeacherForm();
                            NF.Show();
                        }
                        if (u.Role == "Администратор")
                        {
                            MessageBox.Show("Успешный вход!");
                            this.Hide();
                            MainAdminForm NF = new MainAdminForm();
                            NF.Show();
                        }
                        if (u.Role == "Сотрудник дирекции")
                        {
                            MessageBox.Show("Успешный вход!");
                            this.Hide();
                            MainDirectoryForm NF = new MainDirectoryForm();
                            NF.Show();
                        }
                    }
                }
                if (i== false)
                {
                    MessageBox.Show("Вы ввели неверный логин или пароль. Пожалуйста, проверьте еще раз данные");
                }
            }
                catch ( Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString(), "Ошибка!");
                }
        }
        }
        private void AutorizationForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}