﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace система_учета_успеваемости
{
    public partial class MainDirectoryForm : Form
    {
        public MainDirectoryForm()
        {
            InitializeComponent();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            AutorizationForm NF = new AutorizationForm();
            NF.Show();
        }

        private void MainDirectoryForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
