﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace система_учета_успеваемости
{
    public partial class MainAdminForm : Form
    {
        public MainAdminForm()
        {
            InitializeComponent();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            AutorizationForm NF = new AutorizationForm();
            NF.Show();
        }

        private void MainAdminForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void GroupButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddGroupForm NF = new AddGroupForm();
            NF.Show();
        }
    }
}
